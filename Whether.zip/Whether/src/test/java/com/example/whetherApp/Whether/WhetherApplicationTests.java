package com.example.whetherApp.Whether;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhetherApplicationTests {

	@Test
	void contextLoads() {
	}

}
